-Introduction
Indexing API in Java that allows a word index to be created from an e-book. the index contain a list of words that 
relate to the page numbers they appear on and the dictionary defined meaning of the word:

-To run the program, type the following command at the command prompt.
java -cp index.jar gmit.Dictionary

-After running the program, the following menu will be displayed.

********************************************************

============== Select the Book =============
  1 - WarAndPeace-LeoTolstoy.txt
  2 - DeBelloGallico.txt
  3 - PoblachtNaHEireann.txt

  9 - Exit
=============================================

Enter book No..: 

********************************************************

- To select one of the listed books, just type the corresponding number in this case 1 to 3, if you want to leave, 
just precionar 9.

After selecting one of the books, now enter the word you want to locate.

********************************************************
====================================
Enter the word ----> gold

--------------------------- Dictionary and Definition ----------------------------------------
[
"Gold","n.","Alt. of Goolde", 
"Gold","v. t.","A metallic element, constituting the most precious metal, 
   used as a common commercial medium of exchange. It has a characteristic, 
   yellow color, is one of the heaviest substances known (specific gravity, 
   19.32), is soft, and very malleable and ductile. It is quite, 
   unalterable by heat, moisture, and most corrosive agents, and therefore, 
   well suited for its use in coin and jewelry. Symbol Au (Aurum). Atomic, 
   weight 196.7.", 
"Gold","v. t.","Money; riches; wealth.", 
"Gold","v. t.","A yellow color, like that of the metal; as, a flower, 
   tipped with gold.", 
"Gold","v. t.","Figuratively, something precious or pure; as, hearts of, 
   gold."]

------------------------------ Book Detals --------------------------------------
Word.: gold
Book.: WarAndPeace-LeoTolstoy.txt
Indices Pages.: [44, 138, 146, 169, 175, 201, 221, 278, 337, 339, 348, 390, 447, 643, 644, 647, 823, 832, 877, 881, 995, 1044, 1148, 1199, 1331, 1343, 1553, 1556, 1586, 1587, 1588]
Total stop words.: 285558
Total pages.: 1624   Lines.: 64927
----------------------------------------------------------------------------------


